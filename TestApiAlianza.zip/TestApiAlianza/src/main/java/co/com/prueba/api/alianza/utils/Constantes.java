package co.com.prueba.api.alianza.utils;

public class Constantes {
    public static final String URL_ALIANZA = "http://api2.psicoalianza.com/api";
    public static final String ENDPOINT_LOGIN = "/login";
    public static final String RUTA_JSON_LOGIN = "src/test/resources/json/RequestLogin.json";
    public static final String TOKEN = "uWJX7TwS68Ede2OyN43ISjbGU10T1OFF";
    public static final String AUTHORIZATION = "Basic eWhleXNvbi5ndWV2YXJhOlBzaWNvYWxpYW56YTIk";



}
