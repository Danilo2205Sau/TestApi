package co.com.prueba.api.alianza.tasks;

import co.com.prueba.api.alianza.models.DatoLogin;
import co.com.prueba.api.alianza.utils.Constantes;
import co.com.prueba.api.alianza.utils.ReadFile;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Post;

import java.util.List;

import static co.com.prueba.api.alianza.utils.Constantes.*;
import static net.serenitybdd.screenplay.Tasks.instrumented;

public class RealizarPeticion implements Task {
    private DatoLogin datoLogin;

    public RealizarPeticion(List<DatoLogin> datoLogin) {
        this.datoLogin = datoLogin.get(0);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        String body = String.format(ReadFile.returnFile(RUTA_JSON_LOGIN),datoLogin.getUsername(),datoLogin.getPassword());
        actor.attemptsTo(Post.to(ENDPOINT_LOGIN).with(requestSpecification -> requestSpecification
                .header("Content-Type","application/json")
                .header("Authorization",AUTHORIZATION)
                .header("Token",TOKEN)
                .body(body).log().all().relaxedHTTPSValidation()));
        SerenityRest.lastResponse().prettyPrint();

    }
    public static RealizarPeticion deLogin(List<DatoLogin> datoLogin){
        return instrumented(RealizarPeticion.class,datoLogin);
    }
}
