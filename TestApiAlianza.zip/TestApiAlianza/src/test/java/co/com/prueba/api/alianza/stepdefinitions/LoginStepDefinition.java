package co.com.prueba.api.alianza.stepdefinitions;

import co.com.prueba.api.alianza.models.DatoLogin;
import co.com.prueba.api.alianza.questions.ObtenerCodigo;
import co.com.prueba.api.alianza.tasks.RealizarPeticion;
import co.com.prueba.api.alianza.utils.Constantes;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.GivenWhenThen;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import org.hamcrest.Matchers;

import java.util.List;
import java.util.regex.Matcher;

public class LoginStepDefinition {
    Actor usuario = Actor.named("Certificador");
    @Given("^cuento con la api de alianza$")
    public void cuentoConLaApiDeAlianza() {
        usuario.whoCan(CallAnApi.at(Constantes.URL_ALIANZA));
    }


    @When("^el usuario envia la informacion de inicio de sesion$")
    public void elUsuarioEnviaLaInformacionDeInicioDeSesion(List<DatoLogin> data) {
        usuario.attemptsTo(RealizarPeticion.deLogin(data));
    }

    @Then("^la api debe responder de manera exitosa$")
    public void laApiDebeResponderDeManeraExitosa() {
        int codigo = 200;
        usuario.should(GivenWhenThen.seeThat(ObtenerCodigo.deRespuesta(), Matchers.equalTo(codigo)));
    }
}
